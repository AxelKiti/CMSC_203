/*
 * Class: CMSC203 CRN 23999
 * Instructor: Prof. Eivazi
 * Program: MovieDriver.java (Lab 1)
 * Description: Asks the user for information on a movie and returns the info, formatted through a toString method
 * Due: 09/25/2022
 * Platform/compiler: Java
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Axel Kiti
*/
import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Movie movieOfInterest = new Movie();
		
		//Getting the title of the movie into movieTitle
		System.out.println("Please enter the name of a Movie: ");
		String movieTitle = input.nextLine();
		movieOfInterest.setTitle(movieTitle);
		
		//Getting rating of movie into movieRating
		System.out.println("Please enter the movie rating: ");
		String movieRating = input.nextLine();
		movieOfInterest.setRating(movieRating);
		
		//Getting rating of movie into movieRating
		System.out.println("Please enter the number of tickets sold tickets sold for " + movieTitle + ": ");
		int tickets = input.nextInt();
		movieOfInterest.setSoldTickets(tickets);
		
		
		/*Returning all the movie information entered by user
		  (Formatted and put together by toString method) */
		System.out.println(movieOfInterest.toString());
		System.out.println("\nThank you for using this program. Goodbye");
		

	}

}
